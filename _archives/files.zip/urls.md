# BE CHILL — Liste des URL du projet

Projet : Salon de massage BE CHILL
Auteur : Dion Selimi
Formation : EFP Bruxelles

---

## Côté public

| URL | Page | Rôle |
|---|---|---|
| `/index.php` | Accueil | Page d'accueil du salon, présentation générale, soins vedettes, horaires |
| `/soins.php` | Catalogue / Listing | Liste de tous les soins proposés, avec filtres (mot-clé, catégorie, durée) |
| `/soin-detail.php?id=X` | Détail d'un soin | Description complète d'un soin : durée, prix, déroulement, bienfaits, contre-indications |
| `/tarifs.php` | Tarifs | Tableau récapitulatif de tous les prix et formules |
| `/reservation.php` | Réservation | Formulaire de prise de rendez-vous |
| `/apropos.php` | À propos | Histoire du salon, valeurs, équipe |
| `/contact.php` | Contact | Formulaire de contact, coordonnées, horaires, accès |

---

## Côté administration

Toutes les URL admin sont préfixées par `/admin/` et nécessitent une authentification (sauf `login.php`).

| URL | Page | Rôle |
|---|---|---|
| `/admin/login.php` | Connexion | Formulaire de connexion (email + mot de passe) |
| `/admin/dashboard.php` | Tableau de bord | Vue d'ensemble : statistiques, raccourcis, activité récente |
| `/admin/soins-liste.php` | Liste de gestion | Tableau de tous les soins avec actions (modifier, supprimer) |
| `/admin/soin-creer.php` | Création | Formulaire pour ajouter un nouveau soin |
| `/admin/soin-modifier.php?id=X` | Modification | Formulaire pré-rempli pour éditer un soin existant |
| `/admin/logout.php` | Déconnexion | Ferme la session et redirige vers `/admin/login.php` |

### Pages admin prévues pour plus tard (quand la BDD sera en place)

| URL | Page | Rôle |
|---|---|---|
| `/admin/reservations-liste.php` | Liste des réservations | Toutes les réservations clients reçues |
| `/admin/messages-liste.php` | Liste des messages | Messages reçus via le formulaire de contact |

---

## Conventions de nommage

- Les fichiers publics sont à la racine du projet.
- Les fichiers admin sont dans le dossier `/admin/`.
- Les pages de **détail** et de **modification** utilisent un paramètre `?id=X` en GET.
- Les noms de fichiers sont en **minuscules**, sans accent, avec des **tirets** comme séparateurs (ex : `soin-creer.php`).

---

## Arborescence du projet

```
be-chill/
├── index.php
├── soins.php
├── soin-detail.php
├── tarifs.php
├── reservation.php
├── apropos.php
├── contact.php
├── style.css
└── admin/
    ├── login.php
    ├── dashboard.php
    ├── soins-liste.php
    ├── soin-creer.php
    ├── soin-modifier.php
    └── logout.php
```
