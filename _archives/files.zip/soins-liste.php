<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des soins – BE CHILL Administration</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

    <header>
        <p>BE CHILL – Administration</p>
        <p>Gestion des soins</p>
    </header>

    <nav aria-label="Navigation administration">
        <ul>
            <li><a href="dashboard.php">Tableau de bord</a></li>
            <li><a href="soins-liste.php" aria-current="page">Gestion des soins</a></li>
            <li><a href="soin-creer.php">Ajouter un soin</a></li>
            <li><a href="../index.php">Voir le site public</a></li>
            <li><a href="logout.php">Déconnexion</a></li>
        </ul>
    </nav>

    <main>
        <h1>Liste des soins</h1>
        <p>Gérez l'ensemble des soins proposés par le salon. Vous pouvez modifier ou supprimer un soin existant, ou en créer un nouveau.</p>

        <p><a href="soin-creer.php">Ajouter un nouveau soin</a></p>

        <section aria-labelledby="filtrer-soins">
            <h2 id="filtrer-soins">Filtrer la liste</h2>
            <form action="#" method="get">
                <p>
                    <label for="recherche">Rechercher</label>
                    <input type="search" id="recherche" name="recherche" placeholder="Nom du soin">
                </p>
                <p>
                    <label for="categorie">Catégorie</label>
                    <select id="categorie" name="categorie">
                        <option value="">Toutes</option>
                        <option value="classique">Massages classiques</option>
                        <option value="specifique">Massages spécifiques</option>
                    </select>
                </p>
                <p>
                    <button type="submit">Filtrer</button>
                    <button type="reset">Réinitialiser</button>
                </p>
            </form>
        </section>

        <section aria-labelledby="tableau-soins">
            <h2 id="tableau-soins">Tous les soins</h2>
            <table>
                <caption>Liste des soins proposés par le salon</caption>
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Nom</th>
                        <th scope="col">Catégorie</th>
                        <th scope="col">Durée</th>
                        <th scope="col">Prix</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>Massage relaxant</td>
                        <td>Classique</td>
                        <td>60 min</td>
                        <td>65 €</td>
                        <td>
                            <a href="soin-modifier.php?id=1">Modifier</a> |
                            <a href="#">Supprimer</a>
                        </td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Massage suédois</td>
                        <td>Classique</td>
                        <td>60 min</td>
                        <td>70 €</td>
                        <td>
                            <a href="soin-modifier.php?id=2">Modifier</a> |
                            <a href="#">Supprimer</a>
                        </td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Massage suédois</td>
                        <td>Classique</td>
                        <td>90 min</td>
                        <td>95 €</td>
                        <td>
                            <a href="soin-modifier.php?id=3">Modifier</a> |
                            <a href="#">Supprimer</a>
                        </td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>Massage aux pierres chaudes</td>
                        <td>Classique</td>
                        <td>75 min</td>
                        <td>85 €</td>
                        <td>
                            <a href="soin-modifier.php?id=4">Modifier</a> |
                            <a href="#">Supprimer</a>
                        </td>
                    </tr>
                    <tr>
                        <td>5</td>
                        <td>Massage sportif</td>
                        <td>Spécifique</td>
                        <td>60 min</td>
                        <td>70 €</td>
                        <td>
                            <a href="soin-modifier.php?id=5">Modifier</a> |
                            <a href="#">Supprimer</a>
                        </td>
                    </tr>
                    <tr>
                        <td>6</td>
                        <td>Massage dos et nuque</td>
                        <td>Spécifique</td>
                        <td>30 min</td>
                        <td>40 €</td>
                        <td>
                            <a href="soin-modifier.php?id=6">Modifier</a> |
                            <a href="#">Supprimer</a>
                        </td>
                    </tr>
                    <tr>
                        <td>7</td>
                        <td>Réflexologie plantaire</td>
                        <td>Spécifique</td>
                        <td>45 min</td>
                        <td>55 €</td>
                        <td>
                            <a href="soin-modifier.php?id=7">Modifier</a> |
                            <a href="#">Supprimer</a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </section>
    </main>

    <footer>
        <p><small>&copy; 2026 BE CHILL – Administration</small></p>
    </footer>

</body>
</html>
