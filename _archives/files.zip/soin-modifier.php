<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier un soin – BE CHILL Administration</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

    <header>
        <p>BE CHILL – Administration</p>
        <p>Modifier un soin</p>
    </header>

    <nav aria-label="Navigation administration">
        <ul>
            <li><a href="dashboard.php">Tableau de bord</a></li>
            <li><a href="soins-liste.php" aria-current="page">Gestion des soins</a></li>
            <li><a href="soin-creer.php">Ajouter un soin</a></li>
            <li><a href="../index.php">Voir le site public</a></li>
            <li><a href="logout.php">Déconnexion</a></li>
        </ul>
    </nav>

    <main>
        <nav aria-label="Fil d'Ariane">
            <ol>
                <li><a href="dashboard.php">Tableau de bord</a></li>
                <li><a href="soins-liste.php">Gestion des soins</a></li>
                <li aria-current="page">Modifier le soin</li>
            </ol>
        </nav>

        <h1>Modifier un soin</h1>
        <p>Modifiez les informations du soin ci-dessous, puis enregistrez vos changements.</p>

        <form action="soins-liste.php" method="post">
            <input type="hidden" name="id" value="1">

            <fieldset>
                <legend>Informations générales</legend>

                <p>
                    <label for="nom">Nom du soin</label><br>
                    <input type="text" id="nom" name="nom" value="Massage relaxant" required>
                </p>

                <p>
                    <label for="categorie">Catégorie</label><br>
                    <select id="categorie" name="categorie" required>
                        <option value="">-- Choisissez une catégorie --</option>
                        <option value="classique" selected>Massage classique</option>
                        <option value="specifique">Massage spécifique</option>
                    </select>
                </p>

                <p>
                    <label for="duree">Durée (en minutes)</label><br>
                    <input type="number" id="duree" name="duree" min="15" max="180" step="5" value="60" required>
                </p>

                <p>
                    <label for="prix">Prix (en euros)</label><br>
                    <input type="number" id="prix" name="prix" min="0" step="0.01" value="65" required>
                </p>
            </fieldset>

            <fieldset>
                <legend>Description</legend>

                <p>
                    <label for="description-courte">Description courte</label><br>
                    <textarea id="description-courte" name="description-courte" rows="3" cols="50" required>Un massage doux et enveloppant pour relâcher les tensions du quotidien. Idéal pour une première expérience.</textarea>
                </p>

                <p>
                    <label for="description-longue">Description complète</label><br>
                    <textarea id="description-longue" name="description-longue" rows="8" cols="50" required>Le massage relaxant est un soin doux et enveloppant qui vise à détendre l'ensemble du corps. À l'aide de mouvements lents et fluides, votre thérapeute relâche les tensions accumulées et vous aide à retrouver un état de calme profond.</textarea>
                </p>

                <p>
                    <label for="zones">Zones travaillées</label><br>
                    <input type="text" id="zones" name="zones" value="Corps entier (dos, jambes, bras, nuque, pieds)">
                </p>

                <p>
                    <label for="produits">Produits utilisés</label><br>
                    <input type="text" id="produits" name="produits" value="Huiles essentielles biologiques (lavande, ylang-ylang)">
                </p>
            </fieldset>

            <fieldset>
                <legend>Disponibilité</legend>

                <p>
                    <input type="checkbox" id="disponible" name="disponible" value="oui" checked>
                    <label for="disponible">Ce soin est disponible à la réservation</label>
                </p>

                <p>
                    <input type="checkbox" id="vedette" name="vedette" value="oui" checked>
                    <label for="vedette">Afficher ce soin en vedette sur la page d'accueil</label>
                </p>
            </fieldset>

            <p>
                <button type="submit">Enregistrer les modifications</button>
                <a href="soins-liste.php">Annuler</a>
            </p>
        </form>

        <section aria-labelledby="zone-danger">
            <h2 id="zone-danger">Zone dangereuse</h2>
            <p>La suppression d'un soin est définitive et ne peut pas être annulée.</p>
            <form action="soins-liste.php" method="post">
                <input type="hidden" name="id" value="1">
                <input type="hidden" name="action" value="supprimer">
                <button type="submit">Supprimer ce soin</button>
            </form>
        </section>
    </main>

    <footer>
        <p><small>&copy; 2026 BE CHILL – Administration</small></p>
    </footer>

</body>
</html>
