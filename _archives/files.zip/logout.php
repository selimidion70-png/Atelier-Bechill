<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Déconnexion – BE CHILL Administration</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

    <header>
        <p>BE CHILL – Administration</p>
        <p>Déconnexion</p>
    </header>

    <main>
        <h1>Vous êtes déconnecté</h1>
        <p>Votre session a été fermée avec succès. À bientôt !</p>

        <ul>
            <li><a href="login.php">Se reconnecter</a></li>
            <li><a href="../index.php">Retour au site public</a></li>
        </ul>
    </main>

    <footer>
        <p><small>&copy; 2026 BE CHILL – Administration</small></p>
    </footer>

</body>
</html>
