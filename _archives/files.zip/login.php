<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion administration – BE CHILL</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

    <header>
        <p>BE CHILL – Administration</p>
        <p>Espace réservé au personnel du salon</p>
    </header>

    <main>
        <h1>Connexion à l'administration</h1>
        <p>Veuillez vous identifier pour accéder au tableau de bord.</p>

        <form action="dashboard.php" method="post">
            <fieldset>
                <legend>Identifiants</legend>

                <p>
                    <label for="email">Adresse courriel</label><br>
                    <input type="email" id="email" name="email" autocomplete="email" required>
                </p>

                <p>
                    <label for="motdepasse">Mot de passe</label><br>
                    <input type="password" id="motdepasse" name="motdepasse" autocomplete="current-password" required>
                </p>

                <p>
                    <input type="checkbox" id="souvenir" name="souvenir" value="oui">
                    <label for="souvenir">Se souvenir de moi</label>
                </p>
            </fieldset>

            <p>
                <button type="submit">Se connecter</button>
            </p>

            <p><a href="../index.php">Retour au site public</a></p>
        </form>
    </main>

    <footer>
        <p><small>&copy; 2026 BE CHILL – Administration</small></p>
    </footer>

</body>
</html>
