<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord – BE CHILL Administration</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

    <header>
        <p>BE CHILL – Administration</p>
        <p>Bienvenue, Sophie Martin</p>
    </header>

    <nav aria-label="Navigation administration">
        <ul>
            <li><a href="dashboard.php" aria-current="page">Tableau de bord</a></li>
            <li><a href="soins-liste.php">Gestion des soins</a></li>
            <li><a href="soin-creer.php">Ajouter un soin</a></li>
            <li><a href="../index.php">Voir le site public</a></li>
            <li><a href="logout.php">Déconnexion</a></li>
        </ul>
    </nav>

    <main>
        <h1>Tableau de bord</h1>
        <p>Vue d'ensemble de l'activité du salon BE CHILL.</p>

        <section aria-labelledby="statistiques">
            <h2 id="statistiques">Statistiques</h2>
            <dl>
                <dt>Nombre de soins proposés</dt>
                <dd>7</dd>

                <dt>Réservations en attente</dt>
                <dd>4</dd>

                <dt>Réservations du jour</dt>
                <dd>3</dd>

                <dt>Messages non lus</dt>
                <dd>2</dd>
            </dl>
        </section>

        <section aria-labelledby="acces-rapide">
            <h2 id="acces-rapide">Accès rapide</h2>
            <ul>
                <li><a href="soins-liste.php">Gérer la liste des soins</a></li>
                <li><a href="soin-creer.php">Ajouter un nouveau soin</a></li>
                <li><a href="#">Voir les réservations (bientôt disponible)</a></li>
                <li><a href="#">Voir les messages de contact (bientôt disponible)</a></li>
            </ul>
        </section>

        <section aria-labelledby="activite-recente">
            <h2 id="activite-recente">Activité récente</h2>
            <table>
                <caption>Dernières actions sur le site</caption>
                <thead>
                    <tr>
                        <th scope="col">Date</th>
                        <th scope="col">Type</th>
                        <th scope="col">Détail</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>21/04/2026 – 14h32</td>
                        <td>Réservation</td>
                        <td>Nouveau rendez-vous : Massage relaxant – 22/04 à 10h00</td>
                    </tr>
                    <tr>
                        <td>21/04/2026 – 11h15</td>
                        <td>Message</td>
                        <td>Nouveau message de contact reçu</td>
                    </tr>
                    <tr>
                        <td>20/04/2026 – 17h48</td>
                        <td>Réservation</td>
                        <td>Nouveau rendez-vous : Massage sportif – 23/04 à 15h00</td>
                    </tr>
                </tbody>
            </table>
        </section>
    </main>

    <footer>
        <p><small>&copy; 2026 BE CHILL – Administration</small></p>
    </footer>

</body>
</html>
