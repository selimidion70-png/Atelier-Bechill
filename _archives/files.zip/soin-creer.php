<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un soin – BE CHILL Administration</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

    <header>
        <p>BE CHILL – Administration</p>
        <p>Ajouter un nouveau soin</p>
    </header>

    <nav aria-label="Navigation administration">
        <ul>
            <li><a href="dashboard.php">Tableau de bord</a></li>
            <li><a href="soins-liste.php">Gestion des soins</a></li>
            <li><a href="soin-creer.php" aria-current="page">Ajouter un soin</a></li>
            <li><a href="../index.php">Voir le site public</a></li>
            <li><a href="logout.php">Déconnexion</a></li>
        </ul>
    </nav>

    <main>
        <nav aria-label="Fil d'Ariane">
            <ol>
                <li><a href="dashboard.php">Tableau de bord</a></li>
                <li><a href="soins-liste.php">Gestion des soins</a></li>
                <li aria-current="page">Ajouter un soin</li>
            </ol>
        </nav>

        <h1>Ajouter un nouveau soin</h1>
        <p>Remplissez les informations ci-dessous pour ajouter un nouveau soin au catalogue du salon.</p>

        <form action="soins-liste.php" method="post">
            <fieldset>
                <legend>Informations générales</legend>

                <p>
                    <label for="nom">Nom du soin</label><br>
                    <input type="text" id="nom" name="nom" required>
                </p>

                <p>
                    <label for="categorie">Catégorie</label><br>
                    <select id="categorie" name="categorie" required>
                        <option value="">-- Choisissez une catégorie --</option>
                        <option value="classique">Massage classique</option>
                        <option value="specifique">Massage spécifique</option>
                    </select>
                </p>

                <p>
                    <label for="duree">Durée (en minutes)</label><br>
                    <input type="number" id="duree" name="duree" min="15" max="180" step="5" required>
                </p>

                <p>
                    <label for="prix">Prix (en euros)</label><br>
                    <input type="number" id="prix" name="prix" min="0" step="0.01" required>
                </p>
            </fieldset>

            <fieldset>
                <legend>Description</legend>

                <p>
                    <label for="description-courte">Description courte</label><br>
                    <textarea id="description-courte" name="description-courte" rows="3" cols="50" required></textarea>
                </p>

                <p>
                    <label for="description-longue">Description complète</label><br>
                    <textarea id="description-longue" name="description-longue" rows="8" cols="50" required></textarea>
                </p>

                <p>
                    <label for="zones">Zones travaillées</label><br>
                    <input type="text" id="zones" name="zones" placeholder="Ex : dos, jambes, nuque">
                </p>

                <p>
                    <label for="produits">Produits utilisés</label><br>
                    <input type="text" id="produits" name="produits" placeholder="Ex : huiles essentielles biologiques">
                </p>
            </fieldset>

            <fieldset>
                <legend>Disponibilité</legend>

                <p>
                    <input type="checkbox" id="disponible" name="disponible" value="oui" checked>
                    <label for="disponible">Ce soin est disponible à la réservation</label>
                </p>

                <p>
                    <input type="checkbox" id="vedette" name="vedette" value="oui">
                    <label for="vedette">Afficher ce soin en vedette sur la page d'accueil</label>
                </p>
            </fieldset>

            <p>
                <button type="submit">Ajouter le soin</button>
                <button type="reset">Effacer le formulaire</button>
                <a href="soins-liste.php">Annuler</a>
            </p>
        </form>
    </main>

    <footer>
        <p><small>&copy; 2026 BE CHILL – Administration</small></p>
    </footer>

</body>
</html>
